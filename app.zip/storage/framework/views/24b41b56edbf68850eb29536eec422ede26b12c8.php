<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <?php echo $__env->make('head.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <?php echo $__env->make('admin.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <!--main content start-->
        <section class="container-fluid mt-5" id="main-content">
            <section class="wrapper">
                <!-- BASIC FORM VALIDATION -->
                <div class="row mt">
                    <div class="col-lg-8 col-md-8">
                        <?php if(Session::has('message')): ?>
                        <div class="showback">
                            <h3>Alert!</h3>
                            <p class="alert alert-success">
                                <?php echo e(Session::get('message')); ?>

                                <?php echo e(Session::forget('message')); ?>

                            </p>
                        </div>
                        <?php endif; ?>
                        <?php if(Session::has('error')): ?>
                        <div class="showback">
                            <h3>Alert!</h3>
                            <p class="alert alert-danger">
                                <?php echo e(Session::get('error')); ?>

                                <?php echo e(Session::forget('error')); ?>

                            </p>
                        </div>
                        <?php endif; ?>
                        <div class="form-panel">
                            <form role="form" class="form-horizontal style-form" onsubmit="return myconfirmation()"
                                action="<?php echo e(url('/submit_all_loan/'.$pending_month_id)); ?>" method="post"
                                oncopy="return false" oncut="return false" onpaste="return false">
                                <?php echo csrf_field(); ?>
                                <div class="centered">
                                    <h3>Loan Collection</h3><br>
                                    <?php if(!empty($customer_data)): ?>
                                    <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(empty(($cus_data->shop_name))): ?>
                                    <h4><b>Cust Name : </b><?php echo e($cus_data->full_name); ?></h4>
                                    <?php else: ?>
                                    <h4><b>Name : </b><?php echo e($cus_data->shop_name); ?></h4>
                                    <h4><b>Cust Name : </b><?php echo e($cus_data->full_name); ?></h4>
                                    <?php endif; ?>
                                    <h5>Cust Id : <?php echo e($cus_data->id); ?></h5>
                                    <h5>Account No : <?php echo e($cus_data->acc_no); ?></h5>
                                    <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label
                                        class="col-lg-2 col-md-2 col-lg-offset-2 col-md-offset-2 control-label">Pending
                                        Loan</label>
                                    <div class="col-lg-4 col-md-4">
                                        <input type="text" placeholder="Amount" value=<?php echo e($pending); ?> readonly
                                            name="pending_loan" id="pending_loan" style="cursor: not-allowed;"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label
                                        class="col-lg-2 col-md-2 col-lg-offset-2 col-md-offset-2 control-label">Interest</label>
                                    <div class="col-lg-4 col-md-4">
                                        <input type="text" placeholder="Amount" value=<?php echo e($interest); ?> readonly
                                            name="interest_amount" id="interest_amount" style="cursor: not-allowed;"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-2 col-md-2 col-lg-offset-2 col-md-offset-2 control-label">Total
                                        Amount</label>
                                    <div class="col-lg-4 col-md-4">
                                        <input type="text" placeholder="Amount" value=<?php echo e($total); ?> readonly
                                            name="total_amount" id="total_amount" style="cursor: not-allowed;"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label
                                        class="col-lg-2 col-md-2 col-lg-offset-2 col-md-offset-2 control-label">Pin</label>
                                    <div class="col-lg-4 col-md-4">
                                        <input type="text" placeholder="Pin" name="con_pin" id="con_pin"
                                            class="form-control" required>
                                    </div>
                                </div>
                                <?php if($interest_is_calculate==1): ?>
                                <div class="form-group">
                                    <div class="col-lg-6 col-md-6 col-lg-offset-2 col-md-offset-2">
                                        <button class="btn btn-theme" type="submit">Submit</button>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="form-group">
                                    <div class="col-lg-6 col-md-6 col-lg-offset-2 col-md-offset-2">
                                        <a href="<?php echo e(url('/calculate_interest/'.$pending_month_id)); ?>"
                                            class="btn btn-theme">
                                            <span>Calculate Interest</span>
                                        </a>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </form>
                        </div>
                        <!-- /form-panel -->
                    </div>
                    <!-- /col-lg-12 -->
                </div>
                <!-- /row -->
                <!-- /row -->
            </section>
            <!-- /wrapper -->
        </section>
        <!-- /MAIN CONTENT -->
        <!--main content end-->
        <!--footer start-->
        <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--footer end-->
    </section>
    <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
    <script src="lib/form-validation-script.js"></script>

    <script>
    function myconfirmation() {
        var r = confirm("Are You Sure.");
        if (r == true) {
            return true;
        } else {
            return false;
        }
    }
    </script>
</body>

</html><?php /**PATH /home/la9mf9l5d1w1/admin/resources/views/admin/pages/collect_all_loan.blade.php ENDPATH**/ ?>