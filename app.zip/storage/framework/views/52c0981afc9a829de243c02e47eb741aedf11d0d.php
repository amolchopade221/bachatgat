<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <?php echo $__env->make('head.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <!--header start-->
        <?php echo $__env->make('customer.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <!--main content start-->
        <section class="container-fluid" id="main-content">
            <section class="wrapper">
                <h3>Monthly Bachat Statement</h3>
                <div class="row">
                    <div class="col-md-12">
                        <div class="content-panel">
                            <Div class="centered">
                                <h3>Jagtap Bachatgat</h3>
                                <?php if(!empty($customer_data)): ?>
                                <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty(($cus_data->full_name))): ?>
                                <h4><b>Cust Name : </b><?php echo e($cus_data->full_name); ?></h4>
                                <?php else: ?>
                                <h4><b>Name : </b><?php echo e($cus_data->shop_name); ?></h4>
                                <h4><b>Cust Name : </b><?php echo e($cus_data->full_name); ?></h4>
                                <?php endif; ?>
                                <h5>Cust Id : <?php echo e($cus_data->id); ?></h5>
                                <h5>Account No : <?php echo e($cus_data->acc_no); ?></h5>
                                <br>
                                <h4>DETAILS OF MONTHLY STATEMENT</h4>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </Div>
                            <br>
                            <br>

                            <!-- <hr> -->
                            <div style="overflow-x:auto;">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>credited Amt</th>
                                            <th>Pending Amt</th>
                                            <th>Penalty Amt</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                            <th>Penalty Cr. Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(!empty($monthly_statement_data)): ?>
                                        <?php $__currentLoopData = $monthly_statement_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$sr); ?></td>
                                            <td><?php echo e($data->credited); ?></td>
                                            <td><?php echo e($data->pending); ?></td>
                                            <td><?php echo e($data->penalty); ?></td>
                                            <td><?php echo e($data->start_date); ?></td>
                                            <td><?php echo e($data->end_date); ?></td>
                                            <td><?php echo e($data->penalty_credited_date); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </section>
        <!-- /MAIN CONTENT -->
        <!--main content end-->
        <!--footer start-->
        <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--footer end-->
    </section>

    <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
    <!--script for this page-->

</body>

</html><?php /**PATH /home/la9mf9l5d1w1/admin/resources/views/customer/pages/monthly_bachat_statement.blade.php ENDPATH**/ ?>