<!--footer start-->
<footer class="site-footer">
    <div class="text-center">
        <p>
            &copy; Copyrights <strong>Amol</strong>. All Rights Reserved
        </p>
        <div class="credits">
            Created by <a href="https://templatemag.com/"></a>Amol Chopade Mobile No 7057136383
        </div>
        <a href="advanced_table.html#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->
<?php echo $__env->make('script.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amol\Desktop\Bachatgat\resources\views/footer/footer.blade.php ENDPATH**/ ?>