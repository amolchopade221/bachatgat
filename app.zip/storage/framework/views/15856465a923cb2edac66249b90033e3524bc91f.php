<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <?php echo $__env->make('head.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <!--header start-->
        <?php echo $__env->make('customer.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <!--main content start-->
        <section class="container-fluid" id="main-content">
            <section class="wrapper">
                <?php if(Session::has('message')): ?>
                <div class="showback">
                    <h3>Alert!</h3>
                    <p class="alert alert-success">
                        <?php echo e(Session::get('message')); ?>

                        <?php echo e(Session::forget('message')); ?>

                    </p>
                </div>
                <?php endif; ?>
                <?php if(Session::has('error')): ?>
                <div class="showback">
                    <h3>Alert!</h3>
                    <p class="alert alert-danger">
                        <?php echo e(Session::get('error')); ?>

                        <?php echo e(Session::forget('error')); ?>

                    </p>
                </div>
                <?php endif; ?>
                <h3> Statement</h3>
                <div class="row">
                    <div class="col-md-12">
                        <div class="content-panel">
                            <Div class="centered">
                                <h3>Jagtap Bachatgat</h3>
                                <?php if(!empty($customer_data)): ?>
                                <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(empty(($cus_data->shop_name))): ?>
                                <h4><b>Cust Name : </b><?php echo e($cus_data->full_name); ?></h4>
                                <?php else: ?>
                                <h4><b>Name : </b><?php echo e($cus_data->shop_name); ?></h4>
                                <h4><b>Cust Name : </b><?php echo e($cus_data->full_name); ?></h4>
                                <?php endif; ?>
                                <h5>Cust Id : <?php echo e($cus_data->id); ?></h5>
                                <h5>Account No : <?php echo e($cus_data->acc_no); ?></h5>
                                <br>
                                <h4>DETAILS OF STATEMENT</h4>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </Div>
                            <br>
                            <br>

                            <!-- <hr> -->
                            <div style="overflow-x:auto;">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>Transaction Date</th>
                                            <th>Amount(Rs.)</th>
                                            <th>Balance(Rs.)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(!empty($statement_data)): ?>
                                        <?php $__currentLoopData = $statement_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$sr); ?></td>
                                            <td><?php echo e($data->date); ?></td>
                                            <td><?php echo e($data->amount); ?><?php echo e($data->status); ?></td>
                                            <td><?php echo e(($balance=($balance + $data->amount))); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </section>
        <!-- /MAIN CONTENT -->
        <!--main content end-->
        <!--footer start-->
        <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--footer end-->
    </section>
    <!-- js placed at the end of the document so the pages load faster -->

    <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
    <!--script for this page-->

</body>

</html><?php /**PATH /home/la9mf9l5d1w1/admin/resources/views/customer/pages/statement.blade.php ENDPATH**/ ?>