<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <?php echo $__env->make('head.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
    <div id="login-page">
        <div class="container">
            <form class="form-login" action="<?php echo e(url('customer_login')); ?>" method="post" oncopy="return false"
                oncut="return false" onpaste="return false">
                <?php echo csrf_field(); ?>
                <h2 class="form-login-heading">Customer <br> <br> sign in now</h2>
                <div class="login-wrap">
                    <input type="text" class="form-control" name="acc_no" placeholder="Account Number" autofocus>
                    <br>
                    <input type="password" class="form-control" name="password" placeholder="Password">
                    <br>
                    <button class="btn btn-theme btn-block" type="submit"><i class="fa fa-lock"></i>
                        Log In</button>
                </div>
                <div class="showback">
                    <?php if(Session::has('error')): ?>
                    <p class="alert alert-danger">
                        <?php echo e(Session::get('error')); ?>

                    </p>
                    <?php echo e(Session::forget('error')); ?>

                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    <?php echo $__env->make('script.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
    $.backstretch("img/login-bg.jpg", {
        speed: 500
    });
    </script>
</body>

</html><?php /**PATH /home/la9mf9l5d1w1/admin/resources/views/customer/login.blade.php ENDPATH**/ ?>