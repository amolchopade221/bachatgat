 <script src="<?php echo e(asset('lib/jquery.sparkline.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('lib/advanced-datatable/js/DT_bootstrap.js')); ?>"></script>
 <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/advanced-datatable/js/jquery.dataTables.js')); ?>">
 </script>
 <!-- customer page  end-->
 <!--BACKSTRETCH-->
 <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
 <script type="text/javascript" src="<?php echo e(asset('lib/jquery.backstretch.min.js')); ?>"></script>

 <!--common script for all pages-->
 <script type="text/javascript" src="<?php echo e(asset('lib/gritter/js/jquery.gritter.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('lib/gritter-conf.js')); ?>"></script>
 <!--script for this page-->
 <script src="<?php echo e(asset('lib/sparkline-chart.js')); ?>"></script>
 <script src="<?php echo e(asset('lib/zabuto_calendar.js')); ?>"></script>

 <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
 <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
 <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
 <!--common script for all pages-->
 <!--script for this page--><?php /**PATH /home/la9mf9l5d1w1/admin/resources/views/script/script.blade.php ENDPATH**/ ?>