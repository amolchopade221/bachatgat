    <title>JGTP Bachat Gat</title>

    <!-- Favicons -->
    <!-- <link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon"> -->
    <!-- <link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon"> -->

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!--external css-->
    <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/zabuto_calendar.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/gritter/css/jquery.gritter.css')); ?>" />

    <link href="<?php echo e(asset('lib/advanced-datatable/css/demo_page.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('lib/advanced-datatable/css/demo_table.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('lib/advanced-datatable/css/DT_bootstrap.css')); ?>" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">

    <!-- links For Give A Loan -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/bootstrap-fileupload/bootstrap-fileupload.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/bootstrap-datepicker/css/datepicker.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/bootstrap-daterangepicker/daterangepicker.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/bootstrap-timepicker/compiled/timepicker.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/bootstrap-datetimepicker/datertimepicker.css')); ?>" />


    <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('lib/chart-master/Chart.js')); ?>"></script><?php /**PATH C:\Users\Amol\Desktop\Bachatgat\resources\views/head/head.blade.php ENDPATH**/ ?>