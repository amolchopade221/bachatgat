<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <?php echo $__env->make('head.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <!--header start-->
        <?php echo $__env->make('admin.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <!--main content start-->
        <section class="container-fluid" id="main-content">
            <section class="wrapper site-min-height">
                <div class="row mt">
                    <div class="col-lg-12">
                        <?php if(Session::has('message')): ?>
                        <div class="showback">
                            <h3>Alert!</h3>
                            <p class="alert alert-success">
                                <?php echo e(Session::get('message')); ?>

                                <?php echo e(Session::forget('message')); ?>

                            </p>
                        </div>
                        <?php endif; ?>
                        <?php if(Session::has('error')): ?>
                        <div class="showback">
                            <h3>Alert!</h3>
                            <p class="alert alert-danger">
                                <?php echo e(Session::get('error')); ?>

                                <?php echo e(Session::forget('error')); ?>

                            </p>
                        </div>
                        <?php endif; ?>
                        <div class="row content-panel">
                            <!-- /col-md-4 -->
                            <?php if(!empty($customer_data)): ?>
                            <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 centered">
                                <?php if(empty(($cus_data->shop_name))): ?>
                                <h4><b>Account Type : </b>Persnol</h4>
                                <?php else: ?>
                                <h4><b>Account Type : </b>Bussiness</h4>
                                <?php endif; ?>

                                <div class="profile-pic">
                                    <p><img src="<?php echo e(asset('profile/'.$cus_data->profile)); ?>" class="img-circle"></p>
                                    <!-- <p>
                                        <button class="btn btn-theme02"><i class="fa fa-pencil"></i> Edit
                                            Profile</button>
                                    </p> -->
                                </div>
                            </div>
                            <!-- /col-md-4 -->
                            <div class="col-md-8 profile-text">
                                <?php if(empty(($cus_data->shop_name))): ?>
                                <h3><b>Cust Name : </b><?php echo e($cus_data->full_name); ?></h3>
                                <?php else: ?>
                                <h3><b>Name : </b><?php echo e($cus_data->shop_name); ?></h3>
                                <h4><b>Cust Name : </b><?php echo e($cus_data->full_name); ?></h4>
                                <?php endif; ?>
                                <h5>Cust Id : <?php echo e($cus_data->id); ?></h5>
                                <h5>Account No : <?php echo e($cus_data->acc_no); ?></h5>
                                <h5>PAN No : <?php echo e($cus_data->pan); ?></h5>
                                <h5>Addhar No : <?php echo e($cus_data->aadhaar); ?></h5>
                                <h5>Account Open Date : <?php echo e($cus_data->acc_open_date); ?></h5>
                                <h5>Account Expire Date : <?php echo e($cus_data->acc_expire_date); ?></h5>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <!-- /row -->
                    </div>
                    <!-- /col-lg-12 -->
                    <div class="col-lg-12 mt">
                        <div class="row content-panel">
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div id="overview" class="tab-pane active">
                                        <div class="row">
                                            <!-- /col-md-6 -->
                                            <div class="col-md-12 detailed">
                                                <h4>Bachat Status</h4>
                                                <?php if(!empty($customer_data)): ?>
                                                <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row centered mt mb">
                                                    <div class="col-sm-6">
                                                        <h1><i class="fa fa-money"></i></h1>
                                                        <h3><?php echo e($cus_data->balance); ?></h3>
                                                        <h4>Balance</h4>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <h1><i class="fa fa-money"></i></h1>
                                                        <h3><?php echo e($cus_data->per_month_bachat); ?></h3>
                                                        <h4>Monthly Bachat</h4>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detailed">

                                                </div>
                                            </div>
                                            <!-- /col-md-6 -->
                                        </div>
                                        <?php if(!empty($current_month_bachat_data)): ?>
                                        <div>
                                            <h2>Current Month Status</h2>
                                            <div style="overflow-x:auto;">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>credited Amt</th>
                                                            <th>Pending Amt</th>
                                                            <th>Start Date</th>
                                                            <th>End Date</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <?php $__currentLoopData = $current_month_bachat_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($curr_data->credited); ?></td>
                                                            <td><?php echo e($curr_data->pending); ?></td>
                                                            <td><?php echo e($curr_data->start_date); ?></td>
                                                            <td><?php echo e($curr_data->end_date); ?></td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <br>
                                        <?php if(!empty($previous_month_bachat_data)): ?>
                                        <div>
                                            <h2>Pending Collectiom Month's</h2>
                                            <div style="overflow-x:auto;">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>credited Amt</th>
                                                            <th>Pending Amt</th>
                                                            <th>Penalty Amt</th>
                                                            <th>Start Date</th>
                                                            <th>End Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $previous_month_bachat_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prev_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($prev_data->credited); ?></td>
                                                            <td><?php echo e($prev_data->pending); ?></td>
                                                            <td><?php echo e($prev_data->penalty); ?></td>
                                                            <td><?php echo e($prev_data->start_date); ?></td>
                                                            <td><?php echo e($prev_data->end_date); ?></td>
                                                            <?php if(($prev_data->is_calculate) == 0): ?>
                                                            <td><a href="<?php echo e(url('/calculate_penalty/'.$prev_data->id)); ?>"
                                                                    class="btn btn-theme">
                                                                    <span>Calculate Penalty</span>
                                                                </a> </td>
                                                            <?php else: ?>
                                                            <td><a href="<?php echo e(url('/collect_penalty/'.$prev_data->id)); ?>"
                                                                    class="btn btn-theme">
                                                                    <span>Collect Penalty</span>
                                                                </a> </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <!-- /OVERVIEW -->
                                    </div>
                                    <?php if(!empty($customer_data)): ?>
                                    <div class="row">
                                        <!-- /col-md-6 -->
                                        <div class="col-md-12 detailed">
                                            <div class="row centered">
                                                <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-2">
                                                    <p>
                                                        <a href="<?php echo e(url('/statement/'.$cus_data->id)); ?>"
                                                            class="btn btn-theme">
                                                            <span>Bachat Statement</span>
                                                        </a>
                                                    </p>
                                                </div>
                                                <div class="col-md-2">
                                                    <p>
                                                        <a href="<?php echo e(url('/monthly_statement/'.$cus_data->id)); ?>"
                                                            class="btn btn-theme">
                                                            <span>Monthly Status</span>
                                                        </a>
                                                    </p>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <!-- /col-md-6 -->
                                    </div>
                                    <?php endif; ?>

                                    <!-- /tab-pane -->
                                </div>
                                <!-- /tab-content -->
                            </div>
                            <!-- /panel-body -->
                        </div>
                        <!-- /col-lg-12 -->
                    </div>
                    <!-- /col-lg-12 -->
                    <!-- /col-lg-12 -->
                    <div class="col-lg-12 mt">
                        <div class="row content-panel">
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div id="overview" class="tab-pane active">
                                        <div class="row">
                                            <!-- /col-md-6 -->
                                            <div class="col-md-12 detailed">
                                                <h4>Loan Status</h4>
                                                <?php if(!empty($current_loan_data)): ?>
                                                <?php $__currentLoopData = $current_loan_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr_loan_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="row centered mt mb">
                                                    <div class="col-sm-4">
                                                        <h1><i class="fa fa-money"></i></h1>
                                                        <h3><?php echo e($curr_loan_data->amount); ?></h3>
                                                        <h4>Loan Amount</h4>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <h1><i class="fa fa-money"></i></h1>
                                                        <h3><?php echo e($curr_loan_data->pending_loan); ?></h3>
                                                        <h4>Pending Loan</h4>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <h1><i class="fa fa-money"></i></h1>
                                                        <h3><?php echo e($curr_loan_data->interest); ?></h3>
                                                        <h4>Interest</h4>
                                                    </div>
                                                </div>
                                                <div class="row mt mb">
                                                    <div class="col-sm-2">
                                                        <h5>Loan Period</h5>
                                                    </div>
                                                    <div class="col-sm-5">
                                                        <h5>Start Date : <?php echo e($curr_loan_data->start_date); ?></h5>
                                                    </div>
                                                    <div class="col-sm-5">
                                                        <h5>End Date : <?php echo e($curr_loan_data->end_date); ?></h5>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <div class="row centered mt mb">
                                                    <div class="col-sm-4">
                                                        <h1><i class="fa fa-money"></i></h1>
                                                        <h3>0</h3>
                                                        <h4>Loan Amount</h4>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <h1><i class="fa fa-money"></i></h1>
                                                        <h3>0</h3>
                                                        <h4>Pending Loan</h4>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <h1><i class="fa fa-money"></i></h1>
                                                        <h3>0</h3>
                                                        <h4>Interest</h4>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <!-- /col-md-6 -->
                                        </div>
                                        <br>
                                        <!-- /OVERVIEW -->
                                    </div>

                                    <div class="row">
                                        <!-- /col-md-6 -->
                                        <div class="col-md-12 detailed">
                                            <div class="row centered">
                                                <?php if(empty($current_loan_data)): ?>
                                                <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-2">
                                                    <p>
                                                        <a href="<?php echo e(url('/give_a_loan/'.$cus_data->id)); ?>"
                                                            class="btn btn-theme">
                                                            <span>Give A Loan</span>
                                                        </a>
                                                    </p>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <?php $__currentLoopData = $current_loan_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-2">
                                                    <p>
                                                        <a href="<?php echo e(url('/current_month_status/'.$loan_data->loan_no.'/'.$loan_data->id)); ?>"
                                                            class="btn btn-theme">
                                                            <span>Current Month Status</span>
                                                        </a>
                                                    </p>
                                                </div>
                                                <div class="col-md-2">
                                                    <p>
                                                        <a href="<?php echo e(url('/loan_statement/'.$loan_data->loan_no.'/'.$loan_data->id)); ?>"
                                                            class="btn btn-theme">
                                                            <span>Loan Statement</span>
                                                        </a>
                                                    </p>
                                                </div>
                                                <div class="col-md-2">
                                                    <p>
                                                        <a href="<?php echo e(url('/monthly_loan_statement/'.$loan_data->loan_no.'/'.$loan_data->id)); ?>"
                                                            class="btn btn-theme">
                                                            <span>Monthly Status</span>
                                                        </a>
                                                    </p>
                                                </div>
                                                <div class="col-md-2">
                                                    <p>
                                                        <a href="<?php echo e(url('/collect_all_loan/'.$cus_data->id)); ?>"
                                                            class="btn btn-theme">
                                                            <span>Collect All Loan</span>
                                                        </a>
                                                    </p>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <!-- /col-md-6 -->
                                    </div>
                                    <?php if(!empty($previous_loan_data)): ?>
                                    <div>
                                        <h2>Previous Loan Status</h2>
                                        <div style="overflow-x:auto;">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Amount</th>
                                                        <th>interest</th>
                                                        <th>Start Date</th>
                                                        <th>End Date</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $previous_loan_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prev_loan_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($prev_loan_data->loan_no); ?></td>
                                                        <td><?php echo e($prev_loan_data->amount); ?></td>
                                                        <td><?php echo e($prev_loan_data->interest); ?></td>
                                                        <td><?php echo e($prev_loan_data->start_date); ?></td>
                                                        <td><?php echo e($prev_loan_data->end_date); ?></td>
                                                        <td>
                                                            <select name="select_action" class="form-control col-sm-6"
                                                                id="select_action"
                                                                onchange="location = this.options[this.selectedIndex].value;">
                                                                <option selected disabled>Select Action</option>
                                                                <option
                                                                    value="<?php echo e(url('/loan_statement/'.$prev_loan_data->loan_no.'/'.$cus_data->id)); ?>">
                                                                    Loan Statement
                                                                </option>
                                                                <option
                                                                    value="<?php echo e(url('/monthly_loan_statement/'.$prev_loan_data->loan_no.'/'.$cus_data->id)); ?>">
                                                                    Monthly Status
                                                                </option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <br>
                                    <!-- /tab-pane -->
                                </div>
                                <!-- /tab-content -->
                            </div>
                            <!-- /panel-body -->
                        </div>
                        <!-- /col-lg-12 -->
                    </div>
                    <!-- /col-lg-12 -->
                    <div class="col-lg-12 mt">
                        <div class="row content-panel">
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div id="overview" class="tab-pane active">
                                        <div class="row">
                                            <!-- /col-md-6 -->
                                            <div class="col-md-12 detailed">
                                                <div class="row centered">

                                                    <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-2">
                                                        <p>
                                                            <a href="<?php echo e(url('/edit_profile/'.$cus_data->id)); ?>"
                                                                class="btn btn-theme">
                                                                <span>Edit Profile</span>
                                                            </a>
                                                        </p>
                                                    </div>
                                                    <div class="col-md-2">

                                                        <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(($cus_data->status)== 0): ?>
                                                        <p>
                                                            <a href="<?php echo e(url('/block/'.$cus_data->id)); ?>"
                                                                class="btn btn-theme">
                                                                <span>Block</span>
                                                            </a>
                                                        </p>
                                                        <?php elseif(($cus_data->status)== 1): ?>
                                                        <p>
                                                            <a href="<?php echo e(url('/block/'.$cus_data->id)); ?>"
                                                                class="btn btn-theme">
                                                                <span>UnBlock</span>
                                                            </a>
                                                        </p>
                                                        <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </div>
                                            </div>
                                            <!-- /col-md-6 -->
                                        </div>
                                        <!-- /OVERVIEW -->
                                    </div>
                                    <!-- /tab-pane -->
                                </div>
                                <!-- /tab-content -->
                            </div>
                            <!-- /panel-body -->
                        </div>
                        <!-- /col-lg-12 -->
                    </div>
                    <!-- /row -->
                </div>
                <!-- /container -->
            </section>
            <!-- /wrapper -->
        </section>
        <!-- /MAIN CONTENT -->
        <!--main content end-->
        <!--footer start-->
        <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
        <!--footer end-->
    </section>
    <!-- js placed at the end of the document so the pages load faster -->
</body>

</html><?php /**PATH /home/la9mf9l5d1w1/admin/resources/views/admin/pages/profile.blade.php ENDPATH**/ ?>