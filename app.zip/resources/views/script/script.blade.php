 <script src="{{asset('lib/jquery.sparkline.js')}}"></script>
 <script type="text/javascript" src="{{asset('lib/advanced-datatable/js/DT_bootstrap.js')}}"></script>
 <script type="text/javascript" language="javascript" src="{{asset('lib/advanced-datatable/js/jquery.dataTables.js')}}">
 </script>
 <!-- customer page  end-->
 <!--BACKSTRETCH-->
 <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
 <script type="text/javascript" src="{{asset('lib/jquery.backstretch.min.js')}}"></script>

 <!--common script for all pages-->
 <script type="text/javascript" src="{{asset('lib/gritter/js/jquery.gritter.js')}}"></script>
 <script type="text/javascript" src="{{asset('lib/gritter-conf.js')}}"></script>
 <!--script for this page-->
 <script src="{{asset('lib/sparkline-chart.js')}}"></script>
 <script src="{{asset('lib/zabuto_calendar.js')}}"></script>

 <script class="include" type="text/javascript" src="{{asset('lib/jquery.dcjqaccordion.2.7.js')}}"></script>
 <script src="{{asset('lib/jquery.scrollTo.min.js')}}"></script>
 <script src="{{asset('lib/jquery.nicescroll.js')}}" type="text/javascript"></script>
 <!--common script for all pages-->
 <!--script for this page-->