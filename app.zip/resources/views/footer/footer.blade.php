<!--footer start-->
<footer class="site-footer">
    <div class="text-center">
        <p>
            &copy; Copyrights <strong>Amol</strong>. All Rights Reserved
        </p>
        <div class="credits">
            Created by <a href="https://templatemag.com/"></a>Amol Chopade Mobile No 7057136383
        </div>
        <a href="advanced_table.html#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->
@include('script.script')